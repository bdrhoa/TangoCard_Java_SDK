package com.tangocard;

public class TransactionResponse extends Transaction {
	
	public TransactionResponse(String orderID, Card cardInstance) {
		super(orderID, cardInstance);
	}
	
	
}
